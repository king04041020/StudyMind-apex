# StudyMind Apex — source Flutter

Cette archive contient le projet Flutter StudyMind Apex et son workflow GitHub Actions.

## Fonctions intégrées dans cette version
- Interface sombre uniquement, navigation Système / Cours / Quêtes / Profil.
- Progression PR et rangs E, D, C, B, A, S, SS et SSS selon les seuils demandés.
- Création et sauvegarde locale des matières et des préférences.
- Import local de fichiers PDF textuels, TXT et Markdown dans la bibliothèque.
- Extraction du texte des PDF et génération d'une première fiche de révision extractive hors ligne.
- Assistant sélectionnable KING, QUEEN ou Personnalisé, avec personnalité configurable.
- Exercices de démonstration avec validation locale et protection contre le double gain de PR.
- Workflow GitHub Actions pour analyser et compiler l'APK Android.

## Limites importantes
Cette version est une base fonctionnelle améliorée, pas encore une version de production complète.
- L'import PDF fonctionne pour les PDF contenant du texte. Les PDF scannés et les photos nécessitent encore un module OCR.
- La fiche générée est extractive et hors ligne ; ce n'est pas encore une analyse par IA générative.
- L'IA distante, la génération/correction avancée des exercices, la transcription vidéo et la synchronisation Firebase nécessitent un backend configuré et testé.
- L'authentification Firebase et les permissions administrateur ne sont pas activées par une simple interface. La nomination d'administrateurs, l'approbation de la fondatrice, les journaux et la révocation doivent être imposés côté serveur avec des règles de sécurité.
- Aucune clé API, aucun mot de passe ni secret n'est inclus dans le code.

## Identifiant Android
`com.studymind.app` (appliqué par le workflow lors de la génération du projet Android).

## Compilation locale
Depuis `studymind_flutter/` :

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

## Compilation GitHub
Téléverser `studymind-apex-source.zip` à la racine du dépôt. Le workflow `.github/workflows/build-apk.yml` se déclenche au téléversement ou manuellement depuis l'onglet Actions.

## Backend Firebase inclus (à configurer avant activation)
Le dossier `functions/` contient des Cloud Functions TypeScript : génération de contenu via Gemini côté serveur, demandes de rôle administrateur, approbation, révocation et nomination directe réservée à la fondatrice. Les secrets ne sont pas dans l'archive.

Avant déploiement :
1. Associer le dossier au bon projet Firebase avec `firebase use --add`.
2. Remplacer `REPLACE_WITH_FOUNDER_UID` dans `firestore.rules` par l'UID Firebase Auth exact de la fondatrice.
3. Définir le paramètre `STUDYMIND_FOUNDER_UID` avec le même UID.
4. Configurer le secret `GEMINI_API_KEY` dans Firebase Functions Secrets.
5. Installer les dépendances dans `functions/`, compiler, puis déployer les fonctions et les règles Firestore.
6. Intégrer Firebase Auth / Cloud Functions dans l'application Flutter et activer App Check avant une mise en production.

Le backend fourni est du code d'intégration à configurer et tester sur le projet Firebase réel. Les écrans Flutter ne sont pas encore reliés à ces fonctions ; ne pas considérer l'IA cloud ni les rôles administrateur comme actifs avant cette intégration.


## Configuration Firebase Android

Le fichier `google-services.json` est placé dans `studymind_flutter/android/app/`. Firebase Core est initialisé au démarrage de l’application. Les dépendances Firebase Auth et Cloud Firestore sont ajoutées pour les prochaines étapes d’intégration. La clé Gemini ne doit jamais être intégrée à l’APK.
