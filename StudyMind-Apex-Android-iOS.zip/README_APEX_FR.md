# StudyMind Apex — package source

## Structure
- `studymind_flutter/` : application Flutter (interface, comptes Firebase, cours, import PDF/TXT/MD, quêtes locales et chat IA).
- `worker.js` + `wrangler.jsonc` : Worker Cloudflare Gemini/Firebase.
- `functions/` : fonctions Firebase et règles Firestore.
- `.github/workflows/build-apk.yml` : compilation Android APK via GitHub Actions.

## Configuration déjà attendue
- Firebase project : `studymind-4f791`
- Android application ID : `com.studymind.app`
- Cloudflare Worker : `https://studymind-assistant-2026.kayumbagradel05.workers.dev`
- Secrets Cloudflare requis : `FIREBASE_WEB_API_KEY`, `GEMINI_API_KEY`.
- Binding Cloudflare requis : `CHAT_USER_LIMITER` (limite configurée dans `wrangler.jsonc`).

Ne place jamais les clés secrètes Gemini ou Firebase dans le code Flutter ou dans GitHub.

## Mise en place dans GitHub
1. Extraire le contenu de cette archive à la racine du dépôt `StudyMind-apex` (pas le dossier parent de l'archive).
2. Vérifier que `studymind_flutter/`, `worker.js`, `wrangler.jsonc`, `functions/` et `.github/` sont à la racine du dépôt.
3. Commit sur `main`.
4. GitHub Actions > `Build StudyMind Apex APK` > lancer ou suivre le workflow. L'APK sera dans l'artifact `StudyMind-Apex-APK` si la compilation réussit.
5. Le Worker Cloudflare doit être déployé depuis la racine avec `npx wrangler deploy`. Le build Android ne déploie pas le Worker.

## Limites fonctionnelles actuelles
- Les données de progression, les cours et les quêtes de l'interface sont actuellement conservés localement avec SharedPreferences. Ce paquet ne prétend pas encore synchroniser ces données entre appareils.
- Le chat IA nécessite un utilisateur connecté avec Firebase Authentication et envoie le contexte texte du cours sélectionné au Worker.
- L'import PDF extrait le texte intégré au PDF. Les PDF scannés et photos nécessitent encore une fonction OCR.
- La génération automatique persistante des quêtes par IA et la validation anti-doublon côté serveur ne sont pas encore intégrées à l'application Flutter dans cette version.

## Compatibilité Android et iOS

Le projet Flutter utilise une base de code commune. Le workflow GitHub Actions génère les dossiers de plateforme Android et iOS, puis lance une compilation Android APK et une compilation iOS non signée.

**Configuration Firebase iOS obligatoire avant l'exécution réelle :** placez le fichier téléchargé `GoogleService-Info.plist` dans `studymind_flutter/ios/Runner/GoogleService-Info.plist`. Le fichier Android existant `studymind_flutter/android/app/google-services.json` doit être conservé. Les deux applications doivent être enregistrées dans le même projet Firebase avec l'identifiant `com.studymind.app`.

La compilation iOS produite par GitHub Actions est non signée : elle sert à vérifier/compiler l'application, mais ne constitue pas une IPA installable sur iPhone. Une IPA distribuable nécessite une signature Apple et une configuration de certificats/provisioning via macOS/Xcode.
